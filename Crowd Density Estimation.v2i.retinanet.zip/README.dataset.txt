# Crowd Density Estimation > 2026-10-01 12:55pm
https://universe.roboflow.com/vehicle-counting-22wyk/crowd-density-estimation-ej1rl

Provided by a Roboflow user
License: CC BY 4.0

